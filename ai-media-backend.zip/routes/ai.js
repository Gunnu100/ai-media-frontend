
const express = require("express");
const jwt = require("jsonwebtoken");
const User = require("../models/User");
const axios = require("axios");

const router = express.Router();

const authenticate = async (req, res, next) => {
  const authHeader = req.headers.authorization;
  if (!authHeader) return res.status(401).json({ message: "No token" });
  const token = authHeader.split(" ")[1];
  try {
    const payload = jwt.verify(token, process.env.JWT_SECRET);
    req.user = await User.findById(payload.userId);
    next();
  } catch {
    res.status(401).json({ message: "Invalid token" });
  }
};

router.post("/image", authenticate, async (req, res) => {
  const { prompt } = req.body;
  if (req.user.credits <= 0) return res.json({ success: false, message: "No credits left" });

  // Mock AI response or connect to real API
  const imageUrl = `https://via.placeholder.com/512x512?text=${encodeURIComponent(prompt)}`;

  req.user.credits -= 1;
  await req.user.save();

  res.json({ success: true, imageUrl, credits: req.user.credits });
});

router.post("/video", authenticate, async (req, res) => {
  const { prompt } = req.body;
  if (req.user.credits <= 0) return res.json({ success: false, message: "No credits left" });

  // Mock video response (real: connect to Sora or RunwayML)
  const videoUrl = "https://www.w3schools.com/html/mov_bbb.mp4";

  req.user.credits -= 1;
  await req.user.save();

  res.json({ success: true, videoUrl, credits: req.user.credits });
});

module.exports = router;
